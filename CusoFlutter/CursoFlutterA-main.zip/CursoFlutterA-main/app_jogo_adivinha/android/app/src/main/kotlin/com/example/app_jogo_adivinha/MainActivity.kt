package com.example.app_jogo_adivinha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
