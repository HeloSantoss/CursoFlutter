package com.example.ola_mundo_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
