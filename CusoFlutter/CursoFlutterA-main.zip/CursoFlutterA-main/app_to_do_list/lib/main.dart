import 'package:app_to_do_list/TarefaApp.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ListaTarefasApp());
}
