package com.example.app_lista1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
