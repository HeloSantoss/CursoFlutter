class Tarefa {
  String descricao;
  bool concluida;

  // Construtor da classe Tarefa
  Tarefa(this.descricao, this.concluida);
}