// Importação das bibliotecas necessárias do Flutter e Provider
import 'package:app_lista1/TarefasApp.dart';
import 'package:flutter/material.dart';


// Função principal que inicializa o aplicativo
void main() {
  runApp(ListaTarefasApp());
}

// Definição da classe Tarefa, que representa uma tarefa na lista







